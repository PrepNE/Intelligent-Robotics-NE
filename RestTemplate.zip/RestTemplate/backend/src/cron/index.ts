// import cron from "node-cron";
// import { task } from "./task";

// cron.schedule("* * * * *", async () => {
//   console.log("Running scheduled task: task every minute");
//   await task();
// });
