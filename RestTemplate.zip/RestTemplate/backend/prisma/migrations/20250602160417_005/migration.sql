-- AlterTable
ALTER TABLE "plates_log" ADD COLUMN     "amount_charged" DECIMAL(10,2);
