-- AlterTable
ALTER TABLE "plates_log" ALTER COLUMN "payment_timestamp" DROP NOT NULL;
